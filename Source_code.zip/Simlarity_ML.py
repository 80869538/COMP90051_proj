#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Sep  7 23:59:06 2019

@author: jdsmac
"""
from nltk.tokenize import TweetTokenizer

from sklearn.feature_extraction.text import TfidfVectorizer
from Feature_extraction import TF_IDF
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.preprocessing import Normalizer

import pickle
with open("standerdized_train_tweets.txt", "rb") as fp:
            trainTextDict = pickle.load(fp)
order2user = {}
for i,user in enumerate(trainTextDict.keys()):
    order2user[i] = user

tknzr = TweetTokenizer()
feature = TF_IDF()

def getRight(tweet,tweets):
    tweets = tweets.copy()
    tweets.remove(tweet)
    return " ".join(tweets)

def get_tf_idf_query_similarity(query,X):
    query_tfidf = feature.transform(query)
    cosineSimilarities = cosine_similarity(query_tfidf, X).flatten()
    return cosineSimilarities
    
# =============================================================================
# def find_similar( query,X):
#     cosineSimilarities = get_tf_idf_query_similarity(query,X)
#     related_docs_indices = [i for i in cosineSimilarities.argsort()[::-1]]
#     return [(order2user[index], cosineSimilarities[index]) for index in related_docs_indices]
# =============================================================================
    


estimators = [('word_gram', TfidfVectorizer(tokenizer=tknzr.tokenize,ngram_range=(1,2),stop_words = 'english', max_features = 25000))]
X = feature.init_feature(estimators)

print(X.shape)
feature_set = []
for i,key in enumerate(trainTextDict.keys()):
    for tweet in trainTextDict[key]:
       
        print(i)
        new_f = feature.transform(getRight(tweet,trainTextDict[key]))
        
        X[i] = new_f
        feature_set.append(get_tf_idf_query_similarity(tweet,X))
        print(len(feature_set))
        
with open("Similarity_feature.txt", "wb") as fp:
    pickle.dump(feature_set, fp)       