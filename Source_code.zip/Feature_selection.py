#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Aug 30 03:15:02 2019

@author: jdsmac
"""
from nltk.tokenize import TweetTokenizer
from sklearn.feature_selection import chi2
from sklearn.feature_extraction.text import TfidfVectorizer
from Feature_extraction import TF_IDF
import matplotlib.pyplot as plt
from sklearn.decomposition import TruncatedSVD
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import Normalizer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
import pickle
with open("standerdized_test_tweets.txt", "rb") as fp:
            testSet = pickle.load(fp)
tknzr = TweetTokenizer()
feature = TF_IDF()

estimators = [('word_gram', TfidfVectorizer(tokenizer=tknzr.tokenize,ngram_range=(1,3),stop_words = 'english', max_features = 1000000))]

X = feature.init_feature(estimators)
print(X.shape)
with open("standerdized_train_tweets.txt", "rb") as fp:
            trainTextDict = pickle.load(fp)
for user in trainTextDict:
    for tweet in trainTextDict[user]
feature.combined.transform([tweet])
svd = TruncatedSVD(n_components=3000, n_iter=7, random_state=42)
svd.fit(X)  
TruncatedSVD(algorithm='randomized', n_components=5, n_iter=7,
        random_state=42, tol=0.0)
print(svd.explained_variance_ratio_)  

# =============================================================================
# print(X.shape)
# 
# y = list(feature.init_label())
# print(X.shape)
# clf = LogisticRegression(random_state=0, solver='lbfgs',
#                           multi_class='multinomial').fit(X, y)
# print("Start_training")
# 
# clf.score(X, y)
# for tweet in testSet:
#     prediction = clf.predict(feature.combined.transform([tweet]))
#     print(prediction)
# import pickle
# with open("rf", "wb") as fp:
#     pickle.dump(clf, fp)
# 
# =============================================================================
# =============================================================================
# X = feature.init_feature(estimators)
# 
# 
# 
# y = list(feature.init_label())
# 
# print("Start_training")
# clf = linear_model.SGDClassifier(max_iter=1000, tol=1e-3)
# clf.fit(X, y)
# clf.score(X, y)
# for tweet in testSet:
#     prediction = clf.predict(feature.combined.transform([tweet]))
#     print(prediction)
# import pickle
# with open("rf", "wb") as fp:
#     pickle.dump(clf, fp)
# =============================================================================

# =============================================================================
# from sklearn.ensemble import RandomForestClassifier
# 
# clf = RandomForestClassifier(n_estimators=100, max_depth=2,
#                               random_state=0)
# =============================================================================
# =============================================================================
# chi2score = chi2(feature.init_feature(estimators), le.transform(list(feature.init_label())))[0]
# 
# plt.figure(figsize=(15,10))
# wscores = zip(feature.get_feature_names(), chi2score)
# wchi2 = sorted(wscores, key=lambda x:x[1])
# topchi2 = zip(*wchi2[-20:])
# x = range(len(topchi2[1]))
# labels = topchi2[0]
# plt.barh(x,topchi2[1], align='center', alpha=0.2)
# plt.plot(topchi2[1], x, '-o', markersize=5, alpha=0.8)
# plt.yticks(x, labels)
# plt.xlabel('$\chi^2$')
# plt.show()
# =============================================================================
[(3176, 0.1621813742341789), (1541, 0.14872735184166222), (7866, 0.1475308926658265), (5912, 0.14150113477831638), (9048, 0.1382857535430682), (8916, 0.13827461475700267), (5523, 0.13772709211816908), (7722, 0.1373490885226937), (5674, 0.13641400079657987), (4974, 0.13571679008901005)]
20641