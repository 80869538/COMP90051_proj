
# -*- coding: utf-8 -*-
"""
Created on Sat Sep  7 23:22:15 2019

@author: jdsmac
"""
#As usual, in the first step we will import the libraries which we are gonna use.
import pandas as pd #pandas will help us reading the csv data to dataframes(df) and then working on the df.
from collections import Counter #counting of words in the texts
import operator
import numpy as np # linear algebra
import string #for text pre-processing
from nltk.corpus import stopwords #for removing stopwords
import re #Regular expression operations
#For predicting the values
from sklearn.model_selection import KFold #for cross validations(CV)
from scipy import sparse
from sklearn import metrics #for getting CV score


from nltk import word_tokenize


from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.tokenize import TweetTokenizer
from sklearn.metrics.pairwise import cosine_similarity



from sklearn import ensemble, metrics, model_selection, naive_bayes
tknzr = TweetTokenizer()


import numpy as np
from sklearn.pipeline import FeatureUnion

tknzr = TweetTokenizer()
import pandas as pd
import numpy as np
import xgboost as xgb
from sklearn.svm import SVC

from sklearn import preprocessing, decomposition, model_selection, metrics, pipeline
from sklearn.model_selection import GridSearchCV
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn.decomposition import TruncatedSVD
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB

from nltk import word_tokenize
from nltk.corpus import stopwords
stop_words = stopwords.words('english')

#Function for removing punctuations from string
def remove_punctuations_from_string(string1):
    string1 = string1.lower() #changing to lower case
    translation_table = dict.fromkeys(map(ord, string.punctuation), ' ') #creating dictionary of punc & None
    string2 = string1.translate(translation_table) #translating string1
    return string2
#lets check the function on our test string.

print('After processing')

def standardize(tweet):
    tweet = tknzr.tokenize(tweet)
    def is_ascii(s):
        return all(ord(c) < 128 for c in s)
    for index,token in enumerate(tweet):
        #remove handle
        if token == "@handle":
            tweet[index] = ""
        #extract server name
        if re.match(r"http://(.*?)",token):
            tweet[index] = re.match(r"http://(.*?)(/|$)",token)[1]
        #label non english word with format such as __ja__ for japanese
        if not is_ascii(token):
            try:
                tweet[index] ="__" + detect(token) + "__"
                language_feature.add("__" + detect(token) + "__")
            except :
                continue
     
    return " ".join(tweet)

def remove_stopwords_from_string(string1):
    pattern = re.compile(r'\b(' + r'|'.join(stopwords.words('english')) + r')\b\s*') #compiling all stopwords.
    string2 = pattern.sub('', string1) #replacing the occurrences of stopwords in string1
    return string2

print('After processing')

def ngram_list_from_string(string1,count_of_words_in_ngram):
    string1 = string1.lower()
    string1 = string1.replace('.','. ')
    all_grams = ngrams(string1.split(), count_of_words_in_ngram)
    grams_list = []
    for grams in all_grams:
        grams_list.append(grams)
    return(grams_list)

colnames=['author','text']
training_df = pd.read_csv('train_tweets.txt', delimiter = "\t",names=colnames, header=None).dropna()
with open('test_tweets_unlabeled.txt') as f:
     content = f.readlines()
content = [x.strip()for x in content]
testing_df = pd.DataFrame(content)
testing_df.rename(columns={0:'text'}, inplace=True)

training_df["text"] = training_df["text"].apply(lambda x:standardize(x))
testing_df["text"] = testing_df["text"].apply(lambda x:standardize(x))
#Lets take backup of un-processed text, we might need it for future functions.
#We will perform all actions on testing_df aswell to avoid any errors in future.
training_df["text_backup"] = training_df["text"] #Creating new column text_backup same as text.
testing_df["text_backup"] = testing_df["text"] #Creating new column text_backup same as text.


#Applying above made functions on text.
training_df["text"] = training_df["text"].apply(lambda x:remove_punctuations_from_string(x))
training_df["text"] = training_df["text"].apply(lambda x:remove_stopwords_from_string(x))
testing_df["text"] = testing_df["text"].apply(lambda x:remove_punctuations_from_string(x))
testing_df["text"] = testing_df["text"].apply(lambda x:remove_stopwords_from_string(x))

print(training_df.head(5))

training_df['count of words']= training_df["text_backup"].apply(lambda x: len(str(x).split()))
testing_df['count of words']= testing_df["text_backup"].apply(lambda x: len(str(x).split()))

#Feature 2 - Count of characters in a statement
training_df['Count of characters'] = training_df["text_backup"].apply(lambda x: len(str(x)))
testing_df['Count of characters'] = testing_df["text_backup"].apply(lambda x: len(str(x)))

#Feature 3-Diversity_score i.e. Average length of words used in statement
training_df['Average length of words used in statement'] = training_df['Count of characters'] / training_df['count of words']
testing_df['Average length of words used in statement'] = testing_df['Count of characters'] / testing_df['count of words']

print(training_df.head(5))

#The usage of stop words can be another writing pattern. So the fourth feature is count of stopwords.
#Feature_4 = Count of stopwords in the sentence.
stop_words = set(stopwords.words('english'))
training_df['stop words'] = training_df["text_backup"].apply(lambda x: len([w for w in str(x).split() if w in stop_words]) )
testing_df['stop words'] = testing_df["text_backup"].apply(lambda x: len([w for w in str(x).split() if w in stop_words]) )

#Let us identify the highest used words(other than stopwords) in our input data for further feature generation.

#getting all text in single list: Though there are several other quicker options to do this, but
#this is the most accurate and convinient of them.
all_text_without_sw = ''
for i in training_df.itertuples():
    all_text_without_sw = all_text_without_sw +  " ".join(tknzr.tokenize(i.text))
#getting counts of each words:
counts = Counter(re.findall(r"[\w']+", all_text_without_sw))
#deleting ' from counts
del counts["'"]
#getting top 50 used words:
sorted_x = dict(sorted(counts.items(), key=operator.itemgetter(1),reverse=True)[:50])

#Feature-5: The count of top used words.
training_df['count of top used words'] = training_df['text'].apply(lambda x: len([w for w in str(x).lower().split() if w in sorted_x]) )
testing_df['count of top used words'] = testing_df['text'].apply(lambda x: len([w for w in str(x).lower().split() if w in sorted_x]) )

#Similarly lets identify the least used words:
reverted_x = dict(sorted(counts.items(), key=operator.itemgetter(1))[:10000])
#Feature-6: The count of least used words.
training_df['count of least used words'] = training_df['text'].apply(lambda x: len([w for w in str(x).lower().split() if w in reverted_x]) )
testing_df['count of least used words'] = testing_df['text'].apply(lambda x: len([w for w in str(x).lower().split() if w in reverted_x]) )

#Feature-7: Count of punctuations in the input.
training_df['Count of punctuations in the input'] = training_df['text_backup'].apply(lambda x: len([w for w in str(x) if w in string.punctuation]) )
testing_df['Count of punctuations in the input'] = testing_df['text_backup'].apply(lambda x: len([w for w in str(x) if w in string.punctuation]) )

#Feature-8: Count of UPPER case words.
training_df['Count of UPPER case words'] = training_df['text_backup'].apply(lambda x: len([w for w in str(x).replace('I','i').replace('A','a').split() if w.isupper() == True]) )
testing_df['Count of UPPER case words'] = testing_df['text_backup'].apply(lambda x: len([w for w in str(x).replace('I','i').replace('A','a').split() if w.isupper() == True]) )

#Feature-9: Count of Title case words.
training_df['Count of Title case words'] = training_df['text_backup'].apply(lambda x: len([w for w in str(x).replace('I','i').replace('A','a').split() if w.istitle() == True]) )
testing_df['Count of Title case words'] = testing_df['text_backup'].apply(lambda x: len([w for w in str(x).replace('I','i').replace('A','a').split() if w.istitle() == True]) )

#The above features are common features which can indicate a writing pattern. There might be a possibility
#that a writer is using words which START WITH or END WITH particular characters. Lets try to identify them.

starting_words = sorted(list(map(lambda word : word[:2],filter(lambda word : len(word) > 3,all_text_without_sw.split()))))
sw_counts = Counter(starting_words)
top_30_sw = dict(sorted(sw_counts.items(), key=operator.itemgetter(1),reverse=True)[:30])

#Feature-10: Count of (Most words start with)
training_df['Count of (Most words start with)s '] = training_df['text'].apply(lambda x: len([w for w in str(x).lower().split() if w[:2] in top_30_sw and w not in stop_words]) )
testing_df['Feature_10'] = testing_df['text'].apply(lambda x: len([w for w in str(x).lower().split() if w[:2] in top_30_sw and w not in stop_words]) )

#Feature-11: Count of (Most words end with)
ending_words = sorted(list(map(lambda word : word[-2:],filter(lambda word : len(word) > 3,all_text_without_sw.split()))))
ew_counts = Counter(ending_words)
top_30_ew = dict(sorted(ew_counts.items(), key=operator.itemgetter(1),reverse=True)[:30])
training_df['Count of (Most words end with'] = training_df['text'].apply(lambda x: len([w for w in str(x).lower().split() if w[:2] in top_30_ew and w not in stop_words]) )
testing_df['Count of (Most words end with)'] = testing_df['text'].apply(lambda x: len([w for w in str(x).lower().split() if w[:2] in top_30_ew and w not in stop_words]) )

training_df["mean_word_len"] = training_df["text"].apply(lambda x: np.mean([len(w) for w in str(x).split()]))
testing_df["mean_word_len"] = testing_df["text"].apply(lambda x: np.mean([len(w) for w in str(x).split()]))





cols_to_drop = ['text_backup']

train_X = training_df.drop(cols_to_drop, axis=1).dropna()
test_X = testing_df.drop(cols_to_drop, axis=1).dropna()
# =============================================================================
# with open("train_X", "wb") as fp:
#     pickle.dump(train_X, fp)
#     
# #with open("test_X", "wb") as fp:
# #    pickle.dump(test_X, fp)
# with open("train_X", "rb") as fp:
#     train_X = pickle.load(fp) 
# 
# =============================================================================
lbl_enc = preprocessing.LabelEncoder()
y = train_X.author.values

xtrain, xvalid, ytrain, yvalid = train_test_split(train_X, y,
                                                  random_state=42, 
                                                  test_size=0.031, shuffle=True)

print (xtrain.shape)
print (xvalid.shape)

from sklearn.feature_extraction.text import CountVectorizer


tfv = CountVectorizer(tokenizer=tknzr.tokenize,min_df=3, max_features = 20,
            analyzer='word',
            ngram_range=(1, 1), 
            stop_words = 'english')

# Fitting TF-IDF to both training and test sets (semi-supervised learning)
tfv.fit(list(xtrain.text.values) + list(xvalid.text.values))

xtrain_tfv =  tfv.transform(xtrain.text.values) 
xvalid_tfv = tfv.transform(xvalid.text.values)
xtest_tfv = tfv.transform(test_X.text.values)
print(xvalid_tfv)
print("start SVD")
#svd.fit(xtrain_tfv)
#xtrain_svd = svd.transform(xtrain_tfv)
#xvalid_svd = svd.transform(xvalid_tfv)
#xtest_svd = svd.transform(xtest_tfv)

# Scale the data obtained from SVD. Renaming variable to reuse without scaling.
#scl = preprocessing.StandardScaler()
#scl.fit(xtrain_tfv)
xtrain_svd_scl = xtrain_tfv
xvalid_svd_scl = xvalid_tfv
xtest_svd_scl = xtest_tfv

from scipy import sparse

xtrain = sparse.hstack((xtrain_svd_scl,xtrain.drop(['text','author'], axis=1)))
xvalid = sparse.hstack((xvalid_svd_scl,xvalid.drop(['text','author'], axis=1)))
xtest = sparse.hstack((xtest_svd_scl,test_X.drop('text', axis=1)))
# =============================================================================
# from scipy import sparse
# xtrain = sparse.csr_matrix(xtrain)
# xvalid = sparse.csr_matrix(xvalid)
# print(xtrain.shape)
# print(xtest.shape)
# print(xtrain)
# print(xtest)
# from sklearn.naive_bayes import MultinomialNB
# from sklearn.svm import LinearSVC
# clf = LinearSVC(random_state=0, tol=1e-5)
# #clf = MultinomialNB()
# 
# 
# clf.fit(xtrain, ytrain)
# yvalid = yvalid.reshape(-1,1)
# score = clf.score(xvalid,yvalid)
# print(score)
# predictions = clf.predict(xtest)
# print(predictions.shape)
# print(yvalid.shape)
# 
# from sklearn.linear_model import LogisticRegression
# clf = LogisticRegression(random_state=0, solver='lbfgs',multi_class='multinomial').fit(xtrain, ytrain)
# print(clf.score(xvalid,yvalid))
# 
# =============================================================================

def runXGB(train_X, train_y, test_X, test_y=None, test_X2=None, seed_val=0, child=1, colsample=0.3):
    param = {}
    param['objective'] = 'multi:softprob'
    param['eta'] = 0.1
    param['max_depth'] = 3
    param['silent'] = 1
    param['num_class'] = len(set(train_y))
    param['eval_metric'] = "mlogloss"
    param['min_child_weight'] = child
    param['subsample'] = 0.8
    param['colsample_bytree'] = colsample
    param['seed'] = seed_val
    num_rounds = 2

    plst = list(param.items())
    xgtrain = xgb.DMatrix(train_X, label=train_y)

    if test_y is not None:
        xgtest = xgb.DMatrix(test_X, label=test_y)
        watchlist = [ (xgtrain,'train'), (xgtest, 'test') ]
        model = xgb.train(plst, xgtrain, num_rounds, watchlist, early_stopping_rounds=50, verbose_eval=20)
    else:
        xgtest = xgb.DMatrix(test_X)
        model = xgb.train(plst, xgtrain, num_rounds)

    pred_test_y = model.predict(xgtest, ntree_limit = model.best_ntree_limit)
    if test_X2 is not None:
        xgtest2 = xgb.DMatrix(test_X2)
        pred_test_y2 = model.predict(xgtest2, ntree_limit = model.best_ntree_limit)
    return pred_test_y, pred_test_y2, model

print("start training")
pred_val_y, pred_test_y, model = runXGB(xtrain, ytrain, xtest,  seed_val=0)

import matplotlib.pyplot as plt
fig, ax = plt.subplots(figsize=(12,12))
xgb.plot_importance(model, max_num_features=50, height=0.8, ax=ax)
plt.show()
