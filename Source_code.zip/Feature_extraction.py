#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 29 04:22:44 2019

@author: jdsmac
"""
import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.tokenize import TweetTokenizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np
from sklearn.pipeline import FeatureUnion

tknzr = TweetTokenizer()
class TF_IDF():
    
    def __init__(self, char_ngram = 0, ):
        
        with open("standerdized_X_train.txt", "rb") as fp:
            self.trainTextDict = pickle.load(fp) 
        with open("language_feature.txt", "rb") as fp:
            self.language_feature =  pickle.load(fp)
        with open("standerdized_test_tweets.txt", "rb") as fp:
            testSet = pickle.load(fp)
      
        for user in self.trainTextDict:
                self.trainTextDict[user] = " ".join(self.trainTextDict[user])
 
        vocabulary = set(tknzr.tokenize(" ".join(testSet)))
        
          
        self.order2user = {}
        for i,user in enumerate(self.trainTextDict.keys()):
            self.order2user[i] = user

        self.tfidf = TfidfVectorizer(tokenizer=tknzr.tokenize,ngram_range=(1,4),stop_words = 'english',)
        
        estimators = [('word_gram', TfidfVectorizer(tokenizer=tknzr.tokenize,ngram_range=(1,1),stop_words = 'english'))]#, ('cha_gram', TfidfVectorizer(analyzer = 'char',ngram_range=(4,4),min_df=4))]
        self.combined = FeatureUnion(estimators)
        self.tfs = self.combined.fit_transform(self.trainTextDict.values())
        
        
            

    def get_tf_idf_query_similarity(self, query):
        """
        vectorizer: TfIdfVectorizer model
        docs_tfidf: tfidf vectors for all docs
        query: query doc
    
        return: cosine similarity between query and all docs
        """
        query_tfidf = self.combined.transform([query])
        cosineSimilarities = cosine_similarity(query_tfidf, self.tfs).flatten()
        return cosineSimilarities
    def find_similar(self, query, top_n):
        cosineSimilarities = self.get_tf_idf_query_similarity(query)
        related_docs_indices = [i for i in cosineSimilarities.argsort()[::-1]]
        return [(self.order2user[index], cosineSimilarities[index]) for index in related_docs_indices]
    
    def init_feature(self, estimator):
        self.combined = FeatureUnion(estimator)
        self.tfs = self.combined.fit_transform(self.trainTextDict.values())
        return self.tfs
    def init_label(self):
        return self.trainTextDict.keys()
    
    def transform(self,text):
        return self.combined.transform([text])


