#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Sep 11 00:33:51 2019

@author: jdsmac
"""

import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
import matplotlib.pyplot as plt
np.random.seed(32)
from sklearn.preprocessing import LabelEncoder
import re
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score
from sklearn.manifold import TSNE
from nltk.tokenize import TweetTokenizer
from keras.preprocessing.text import Tokenizer
from keras.preprocessing.sequence import pad_sequences
from keras.layers import LSTM, Conv1D, MaxPooling1D, Dropout
from keras.utils.np_utils import to_categorical
tknzr = TweetTokenizer()
def standardize(tweet):
    tweet = tknzr.tokenize(tweet)
    def is_ascii(s):
        return all(ord(c) < 128 for c in s)
    for index,token in enumerate(tweet):
        #remove handle
        if token == "@handle":
            tweet[index] = ""
        #extract server name
        if re.match(r"http://(.*?)",token):
            tweet[index] = re.match(r"http://(.*?)(/|$)",token)[1]
        #label non english word with format such as __ja__ for japanese
        if not is_ascii(token):
            try:
                tweet[index] ="__" + detect(token) + "__"
                language_feature.add("__" + detect(token) + "__")
            except :
                continue
     
    return " ".join(tweet)

colnames=['author','text']
training_df = pd.read_csv('train_tweets.txt', delimiter = "\t",names=colnames, header=None).dropna()
with open('test_tweets_unlabeled.txt') as f:
     content = f.readlines()
content = [x.strip()for x in content]
testing_df = pd.DataFrame(content)
testing_df.rename(columns={0:'text'}, inplace=True)

training_df["text"] = training_df["text"].apply(lambda x:standardize(x))
testing_df["text"] = testing_df["text"].apply(lambda x:standardize(x))


encoder = LabelEncoder()
y = training_df['author'].values
encoder.fit(y)
y = encoder.transform(y)
print(y)
train_text, test_text,train_y = training_df['text'],testing_df["text"],y
print(train_y)
print('Train text shape:' + str(train_text.shape))

MAX_NB_WORDS = 20000

# get the raw text data
texts_train = train_text.astype(str)
texts_test = test_text.astype(str)

# finally, vectorize the text samples into a 2D integer tensor
tokenizer = Tokenizer(nb_words=MAX_NB_WORDS, char_level=False)
tokenizer.fit_on_texts(texts_train)
sequences = tokenizer.texts_to_sequences(texts_train)
sequences_test = tokenizer.texts_to_sequences(texts_test)

word_index = tokenizer.word_index
print('Found %s unique tokens.' % len(word_index))

index_to_word = dict((i, w) for w, i in tokenizer.word_index.items())
print(" ".join([index_to_word[i] for i in sequences[0]]))

seq_lens = [len(s) for s in sequences]
print("average length: %0.1f" % np.mean(seq_lens))
print("max length: %d" % max(seq_lens))


import matplotlib.pyplot as plt


plt.hist([l for l in seq_lens if l < 140], bins=50)
plt.show()
# =============================================================================
# MAX_SEQUENCE_LENGTH = 40
# 
# # pad sequences with 0s
# x_train = pad_sequences(sequences, maxlen=MAX_SEQUENCE_LENGTH)
# x_test = pad_sequences(sequences_test, maxlen=MAX_SEQUENCE_LENGTH)
# print('Shape of data tensor:', x_train.shape)
# print('Shape of data test tensor:', x_test.shape)
# 
# y_train = train_y
# 
# 
# y_train = to_categorical(np.asarray(y_train),num_classes=len(np.unique(y_train)))
# print('Shape of label tensor:', y_train.shape)
# 
# from keras.layers import Dense, Input, Flatten
# from keras.layers import GlobalAveragePooling1D, Embedding
# from keras.models import Model
# 
# EMBEDDING_DIM = 100
# N_CLASSES = 2
# 
# # input: a sequence of MAX_SEQUENCE_LENGTH integers
# sequence_input = Input(shape=(MAX_SEQUENCE_LENGTH,), dtype='int32')
# 
# embedding_layer = Embedding(MAX_NB_WORDS, EMBEDDING_DIM,
#                             input_length=MAX_SEQUENCE_LENGTH,
#                             trainable=True)
# embedded_sequences = embedding_layer(sequence_input)
# 
# average = GlobalAveragePooling1D()(embedded_sequences)
# predictions = Dense(9293, activation='softmax')(average)
# 
# model = Model(sequence_input, predictions)
# model.compile(loss='categorical_crossentropy',
#               optimizer='adam', metrics=['acc'])
# model.fit(x_train, y_train, validation_split=0.031,
#           nb_epoch=30, batch_size=4096,shuffle=True)
# 
# output_test = model.predict(x_test)
# output_test = np.argmax(output_test,axis = 1)
# print(output_test)
# output_test = encoder.inverse_transform(output_test)
# def generate_result(result):
#     r = []
#     for i,item in enumerate(result):
#         r.append({"Id":i+1,"Predicted":item})
#         
#     df = pd.DataFrame(r)
#     df.to_csv("2.csv",index = False)
# generate_result(output_test)
# sequence_input = Input(shape=(MAX_SEQUENCE_LENGTH,), dtype='int32')
# embedded_sequences = embedding_layer(sequence_input)
# 
# x = LSTM(128, dropout=0.2, recurrent_dropout=0.2)(embedded_sequences)
# predictions = Dense(2, activation='softmax')(x)
# 
# 
# model = Model(sequence_input, predictions)
# model.compile(loss='categorical_crossentropy',
#               optimizer='adam',
#               metrics=['acc'])
# model.fit(x_train, y_train, validation_split=0.1,
#           nb_epoch=2, batch_size=128)
# output_test = model.predict(x_test)
# print("test auc:", roc_auc_score(y_test,output_test[:,1]))
# =============================================================================
