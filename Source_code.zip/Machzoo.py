#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Sep  7 20:11:24 2019

@author: jdsmac
"""

import matchzoo as mz
import pickle
import pandas as pd
with open("standerdized_train_tweets.txt", "rb") as fp:
    trainTextDict = pickle.load(fp) 
    
def getRightText(left,right):
    r = right.copy()
    r.remove(left)
  
    return " ".join(r)
j = 0
id_right = []

text_left = []
text_right = []
for user in  trainTextDict:
    i = 0
    j+=1
    for tweet in trainTextDict[user]:
        
        id_right.append(str(user))
        text_left.append(tweet)
        text_right.append(str(user))
        i+=1
    if j>10:
        break;
data = pd.DataFrame({
    'text_left': text_left,
    'text_right': text_right,
    "id_right":id_right
})
my_pack = mz.pack(data)
print(my_pack.frame().head())

preprocessor = mz.preprocessors.CDSSMPreprocessor(fixed_length_left=10, fixed_length_right=10)
train_processed = preprocessor.fit_transform(my_pack)
preprocessor.fit(my_pack)
train_pack_processed = preprocessor.transform(my_pack)
model = mz.models.CDSSM()
model.params['input_shapes'] = preprocessor.context['input_shapes']

model.params['filters'] = 64
model.params['kernel_size'] = 3
model.params['strides'] = 1
model.params['padding'] = 'same'
model.params['conv_activation_func'] = 'tanh'
model.params['w_initializer'] = 'glorot_normal'
model.params['b_initializer'] = 'zeros'
model.params['mlp_num_layers'] = 1
model.params['mlp_num_units'] = 64
model.params['mlp_num_fan_out'] = 64
model.params['mlp_activation_func'] = 'tanh'
model.params['dropout_rate'] = 0.8
model.params['optimizer'] = 'adadelta'
model.guess_and_fill_missing_params()
model.build()
model.compile()
model.backend.summary()
x, y = train_processed.unpack()
model.fit(x, y, batch_size=32, epochs=5)
print('num batches:', len(train_generator))
history = model.fit_generator(train_generator, epochs=20, callbacks=[evaluate], workers=1, use_multiprocessing=False)
preprocessor.context
ranking_task = mz.tasks.Ranking(loss=mz.losses.RankCrossEntropyLoss(num_neg=4))
ranking_task.metrics = [
    mz.metrics.NormalizedDiscountedCumulativeGain(k=3),
    mz.metrics.NormalizedDiscountedCumulativeGain(k=5),
    mz.metrics.MeanAveragePrecision()
]

model = mz.models.DSSM()
model.params['input_shapes'] = preprocessor.context['input_shapes']
model.params['task'] = ranking_task
model.params['mlp_num_layers'] = 3
model.params['mlp_num_units'] = 300
model.params['mlp_num_fan_out'] = 128
model.params['mlp_activation_func'] = 'relu'
model.guess_and_fill_missing_params()
model.build()
model.compile()
model.backend.summary()

train_generator = mz.DataGenerator(train_pack_processed, num_dup=1, num_neg=4, batch_size=32, shuffle=True)
len(train_generator)
history = model.fit_generator(train_generator, epochs=20, callbacks=[evaluate], workers=5, use_multiprocessing=False)

train_processed = preprocessor.transform(my_pack)
train_processed.left.head()
vocab_unit = preprocessor.context['vocab_unit']
print('Orig Text:', train_processed.left.loc['L-0']['text_left'])
sequence = train_processed.left.loc['L-0']['text_left']
print('Transformed Indices:', sequence)
print('Transformed Indices Meaning:',
      '_'.join([vocab_unit.state['index_term'][i] for i in sequence]))
model = mz.models.dssm.DSSM()
print(model.params)
task = mz.tasks.Ranking()
model.params['task'] = task
model.params['mlp_num_units'] = 3
print(model.params)
print(preprocessor.context['input_shapes'])
model.params.update(preprocessor.context)

model.params.completed()
model.build()
model.compile()
model.backend.summary()
x, y = train_processed.unpack()
model.fit(x, y, batch_size=32, epochs=5)