#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 29 06:24:16 2019

@author: jdsmac
"""
from Feature_extraction import TF_IDF
import pandas as pd
import pickle
import numpy as np

feature = TF_IDF()

def generate_result(result):
    r = []
    for i,item in enumerate(result):
        r.append({"Id":i+1,"Predicted":item})
        
    df = pd.DataFrame(r)
    df.to_csv("1.csv",index = False)


colnames=['userID','text']
df = pd.read_csv('X_test.txt', delimiter = "\t",names=colnames, header=None).dropna()

     
predicted = []
i = 0
for tweet in df['text'].values:
 
    prediction =feature.find_similar(tweet,10)
    print(len(prediction))
    predicted.append(prediction[0][0])
    print(len(predicted))



def multiclass_logloss(actual, predicted, eps=1e-15):
    """Multi class version of Logarithmic Loss metric.
    :param actual: Array containing the actual target classes
    :param predicted: Matrix with class predictions, one probability per class
    """
    # Convert 'actual' to a binary array if it's not already:
    if len(actual.shape) == 1:
        actual2 = np.zeros((actual.shape[0], predicted.shape[1]))
        for i, val in enumerate(actual):
            actual2[i, val] = 1
        actual = actual2

    clip = np.clip(predicted, eps, 1 - eps)
    rows = actual.shape[0]
    vsota = np.sum(actual * np.log(clip))
    return -1.0 / rows * vsota
multiclass_logloss(df['userID'].values,np.asarray(predicted))