#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Sep 11 13:09:29 2019

@author: jdsmac
"""

from nltk.tokenize import TweetTokenizer
import re
import pandas as pd
from langdetect import detect, DetectorFactory
DetectorFactory.seed = 0

tknzr = TweetTokenizer()
language_feature = set()
def standardize(tweet):
    tweet = tknzr.tokenize(tweet)
 
    for index,token in enumerate(tweet):
        #remove handle
        if token == "@handle":
            tweet[index] = ""
        #extract server name
        if re.match(r"http://(.*?)",token):
            tweet[index] = re.match(r"http://(.*?)(/|$)",token)[1]
        #label non english word with format such as __ja__ for japanese
        if not token.isascii():
            try:
                tweet[index] ="__" + detect(token) + "__"
                language_feature.add("__" + detect(token) + "__")
            except :
                continue
     
    return " ".join(tweet)
# =============================================================================
# generate standard training set as dictionary in 
# type dictionary with format: {"userID":[all tweets strings]}   
# =============================================================================
colnames=['userID','text']
df = pd.read_csv('X_test.txt', delimiter = "\t",names=colnames, header=None).dropna()
tempo = df.to_dict()
textDict = {}
  
for i,item in tempo['text'].items():
    if tempo['userID'][i] not in textDict:
        textDict[tempo['userID'][i]] = [standardize(item)]
    else:
        textDict[tempo['userID'][i]].append(standardize(item))
        
import pickle
with open("standerdized_X_test.txt", "wb") as fp:
    pickle.dump(textDict, fp)
 